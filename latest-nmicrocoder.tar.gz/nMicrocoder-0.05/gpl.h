void print_gpl();
void ende();

